import { Box, ThemeProvider, Typography, createTheme } from "@mui/material";
import React from "react";
import { naturalOilDatas } from "./CardDatas";
import BestSellerCards from "../features/BestSallerCards";

const NaturalOilStoreLoop = () => {
  return (
    <Box>
      <Box
        textAlign={{
          lg: "start",
          sm: "center",
          md: "start",
          xs: "center",
        }}
      >
        <Typography variant="h5" mt={6} fontWeight={600}>
          Natural oil store
        </Typography>
      </Box>
      <Box
        mt={5}
        sx={{
          display: "flex",
          gap: "20px",
          flexWrap: "wrap",
          cursor: "pointer",
        }}
        justifyContent={{
          lg: "space-between",
          sm: "center",
          md: "center",
          xs: "center",
        }}
        gap={{ sm: "20px", md: "20px", lg: "20px", xl: "8px" }}
      >
        {naturalOilDatas.map((item) => {
          console.log(item, "item ");
          return (
            <Box>
              <BestSellerCards card={item} />
            </Box>
          );
        })}
      </Box>
    </Box>
  );
};

export default NaturalOilStoreLoop;
