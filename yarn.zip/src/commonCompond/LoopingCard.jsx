import { useEffect, useState } from "react";
import BestSellerCards from "../features/BestSallerCards";
import { cardDatas } from "./CardDatas";
import { Box, Typography } from "@mui/material";

export default function LoopingCard(props) {
  console.log(props.checkValue, "props.checkValue");

  const [cardData, setCardData] = useState(cardDatas);
  useEffect(() => {
    if (props.checkValue !== "") {
      const filteredCards = cardDatas.filter((item) =>
        item.name.includes(props.checkValue)
      );
      setCardData(filteredCards);

      console.log(filteredCards, "filteredCards", props.checkValue);
    } else {
      setCardData(cardDatas);
    }
  }, [props.checkValue]);

  const handleShowAnotherComponent = () => {
    props.setShowAnotherComponent(true);
  };
  return (
    <Box>
      <Box
        textAlign={{
          lg: "start",
          sm: "center",
          md: "start",
          xs: "center",
        }}
      >
        <Typography variant="h5" mt={6} fontWeight={600}>
          Best Sellers
        </Typography>
      </Box>
      <Box
        mt={5}
        sx={{
          display: "flex",
          gap: "20px",
          flexWrap: "wrap",
          cursor: "pointer",
        }}
        justifyContent={{
          lg: "space-between",
          sm: "center",
          md: "center",
          xs: "center",
        }}
        gap={{ sm: "20px", md: "20px", lg: "20px", xl: "8px" }}
      >
        {cardData.map((item) => {
          console.log(item, "item234");
          return (
            <Box key={item.id}>
              <BestSellerCards
                card={item}
                handleShowAnotherComponent={handleShowAnotherComponent}
              />
            </Box>
          );
        })}
      </Box>
    </Box>
  );
}
