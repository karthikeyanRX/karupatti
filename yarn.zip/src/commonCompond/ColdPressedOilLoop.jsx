import { Box, Typography } from "@mui/material";
import React from "react";
import { coldPressedOillDatas } from "./CardDatas";
import BestSellerCards from "../features/BestSallerCards";

const ColdPressedOilLoop = () => {
  return (
    <Box>
      <Box
        textAlign={{
          lg: "start",
          sm: "center",
          md: "start",
          xs: "center",
        }}
      >
        <Typography variant="h5" mt={6} fontWeight={600}>
          Cold pressed oil(6)
        </Typography>
      </Box>
      <Box
        mt={5}
        sx={{
          display: "flex",
          cursor: "pointer",
          gap: "20px",
          flexWrap: "wrap",
          borderBottom: "1px solid gray",
          paddingBottom: "80px",
        }}
        justifyContent={{
          lg: "space-between",
          sm: "center",
          md: "flex-start",
          xs: "center",
        }}
        // gap={{ sm: "20px", md: "10rem", lg: "7rem", xl: "5rem" }}
      >
        {coldPressedOillDatas.map((item) => {
          console.log(item, "item ");
          return (
            <Box>
              <BestSellerCards card={item} />
            </Box>
          );
        })}
      </Box>
    </Box>
  );
};

export default ColdPressedOilLoop;
